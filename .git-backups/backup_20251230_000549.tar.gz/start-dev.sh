#!/bin/bash
cd /mnt/hdd/growth_hub/web-app
npm run dev -- --host 0.0.0.0
